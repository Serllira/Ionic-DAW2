export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyBBaXNeklPjOAYNQ15MlRWTe2nWuHhEmns",
    authDomain: "daw2login.firebaseapp.com",
    databaseURL: "https://daw2login.firebaseio.com",
    projectId: "daw2login",
    storageBucket: "daw2login.appspot.com",
    messagingSenderId: "788799162758"
  }
};
